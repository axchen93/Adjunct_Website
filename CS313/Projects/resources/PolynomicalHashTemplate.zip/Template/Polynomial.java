import java.io.*;

public class Polynomial implements PolynomialInterface{

    private HashMap<Integer, Integer> Polynomial;

    public Polynomial(String s) {
        
    }

    public Polynomial divide(Polynomial p) throws Exception{
        throw new UnsupportedOperationException("Not implemented");
    }
    public Polynomial remainder(Polynomial p) throws Exception{
        throw new UnsupportedOperationException("Not implemented");
    }

    public final String toString() {
        //fill in a toString method to print your polynomials
    }
}