interface LinkedListInterface<T>{
    public boolean isEmpty();
    public int size();
    public void insert(Node<T> spot);   
}