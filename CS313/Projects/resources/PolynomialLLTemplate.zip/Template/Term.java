class Term{
    private int coefficent, power;
}