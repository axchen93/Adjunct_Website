class SinglyLinkedList<T> implements LinkedListInterface<T>{

}